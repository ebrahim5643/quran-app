QURAN READER - Android Studio project
=====================================
1. Install Android Studio (free): https://developer.android.com/studio
2. File > Open > choose this QuranApp folder. Wait for "Gradle sync" to finish (needs internet once).
3. Build the APK:  Build > Build Bundle(s) / APK(s) > Build APK(s)
   The file appears at: app/build/outputs/apk/debug/app-debug.apk
4. Copy the APK to your phone, tap it, allow "install unknown apps" and install.
   (Or plug the phone in with USB debugging and press the green Run button.)

The whole app UI lives in: app/src/main/assets/index.html
On first launch the app downloads the Quran text once (internet needed), then works offline.
